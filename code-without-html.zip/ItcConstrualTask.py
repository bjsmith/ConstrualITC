from IntertemporalChoiceTask import *
from pandas import *
import math
from enum import *


# a python class to read in Bob Spunt's 2016 construal task and insert it into James Melrose's ITC
class ItcConstrualTask(IntertemporalChoiceTask):
    def __init__(self, n, subid, day, runid, salience_condition=None, construal_condition=None, task_version='generic',
                 mean_intertask_interval=2,
                 mean_intratask_interval=1,
                 min_intertask_interval=0.5,
                 min_intratask_interval=0.5,
                 require_balance_from_trial=None
                 ):
        IntertemporalChoiceTask.__init__(self, n=n, subid=subid, day=day,
                                         runid=runid, salience_condition=salience_condition,
                                         task_version=task_version,
                                         mean_intertask_interval=mean_intertask_interval,
                                         mean_intratask_interval=mean_intratask_interval,
                                         min_intertask_interval=min_intertask_interval,
                                         min_intratask_interval=min_intratask_interval,
                                         require_balance_from_trial=require_balance_from_trial
                                         )
        if construal_condition is None:
            # raise Exception("need to insert code here for selecting a salience condition based on other data")
            # we set construal condition in this way to balance it with salience_condition
            # this way, precisely half of subjects in each salience condition will be in each construal condition
            self.construal_condition = int((math.floor(subid / 2) + runid) % 2)



    def populate_construal_itc_task_with_parameters(self, construal_set_ids):
        self.populate_itc_task_with_parameters()
        # we have three sessions of two runs of ITC
        # every subject consistently has the same salience condition first
        # we'll make each subject also consistently have the same construal ITC task first.
        # but we'll counterbalance construal task and salience condition

        construal_stim = pandas.read_csv('spunt_dataset/stim.csv')
        construal_data = pandas.read_csv('spunt_dataset/data.csv')
        construal_seeker = pandas.read_csv('spunt_dataset/seeker.csv')

        #    %% SEEKER column key %%
        #    % 1 - trial #
        #    % 2 - cond (1=1to2, 2=2to3, 3=3to4, 4=2to1, 5=3to2, 6=4to3)
        #    % 3 - correct (normative) response (1=Yes, 2=No)
        #    % 5 - scheduled question onset
        #    % 6 - (added above) scheduled action onset
        #    % 7 - (added below) actual question onset (s)
        #    % 8 - (added below) actual action onset (s)
        #    % 9 - (added below) actual response [0 if NR]
        #    % 10 - (added below) response time (s) [0 if NR]


        construal_data['StimulusId'] = range(0, 144)
        construal_stim['StimulusId'] = range(0, 144)
        # so we want to use the stimulus column in Seeker to index stimulus and data
        # do we need other stuff from seekers?
        # we want cond,correct, so yes.

        # this was used before I wrote my own code to select construal trials.
        # construal_all_trials = construal_seeker. \
        #    merge(construal_stim, how='left', left_on='Stimulus', right_on='StimulusId'). \
        #    merge(construal_data, how='left', left_on='Stimulus', right_on='StimulusId')
        construal_all_trials = construal_stim.merge(construal_data, how='left', on='StimulusId')

        construal_all_trials = \
            pandas.concat([
                construal_all_trials,
                pandas.DataFrame(construal_all_trials.q_and_a.str.split('?', 1).tolist(),
                                 columns=['QuestionText', 'AnswerText'])
            ], axis=1)
        # great, we've concatenated them. now

        construal_all_trials['QuestionText'] = construal_all_trials['QuestionText'] + '?'
        #    % 4 - stimulus # (corresponds to row in stim & data, see above)
        # we only want the first condition for now - that's the first 72




        construal_all_trials = construal_all_trials.rename(columns={'Condition_x': 'Condition'})

        # this iterates through all of the construal stimuli to get sets that are each individually
        # well-distributed on important dimensions
        # this has to be consistent across runs, because it generates values for both runs.
        # if we don't make it consistent then we'd risk assigning the same values to both runs.
        # if pre_loaded_construal_set is None:
        #     random.seed(self.get_pseudorandom_seed('BalancedConstrualSet',consistent_across_runs=True))
        #     balanced_construal_sets=self.get_balanced_construal_set(n_trials=self.n_trials,n_runs=n_runs_total)
        # else
        #     balanced_construal_sets=pre_loaded_construal_set


        # this is inefficient; it essentially generates the same set repeatedly. That's OK though,
        # the finding the set itself is fairly fast.
        # construal_run = construal_all_trials.loc[:, ['QuestionText', 'AnswerText', 'Condition']].iloc[
        #    balanced_construal_sets[0]]
        # elif self.construal_condition == 1:
        construal_run = construal_all_trials.loc[:, ['QuestionText', 'AnswerText', 'Condition']].iloc[
            construal_set_ids]

        # construal_run=construal_run.reindex(range(0,72))

        construal_run = construal_run.rename(columns={c: ('Construal_' + c) for c in construal_run.columns})

        construal_run.reset_index(drop=True, inplace=True)
        # print citc_task.task_data.index.values
        # print construal_run.index.values
        self.task_data = pandas.concat([self.task_data, construal_run], axis=1)
        # citc_task.task_data.combine_first(construal_run)
        # print citc_task.task_data


def get_balanced_construal_set(n_trials, n_runs, n_repeats=1):
    """

    :param n_trials: int describing number of trials in each run, or n_runs-length list describing number of trials in each run.
    :param n_runs: number of runs.
    :return:
    """
    # construal_seeker = pandas.read_csv('spunt_dataset/seeker.csv')
    construal_data = pandas.read_csv('spunt_dataset/data.csv')
    construal_data['Q_Mean'] = construal_data.loc[:, ['Q_Body', 'Q_Spec', 'Q_Conc', 'Q_Imag']].mean(1)
    construal_data['A_Mean'] = construal_data.loc[:, ['A_Body', 'A_Spec', 'A_Conc', 'A_Imag']].mean(1)
    all_db_means = construal_data.mean(0)

    getconditionprops = lambda x: x.groupby('Condition').count()['A_Mean'] / x.count()['A_Mean']
    getconditionvals = lambda x: x.groupby('Condition').count()['A_Mean']

    # all_db_means=pandas.concat([all_db_means,getconditionprops(construal_data)])


    # loop through possible candidate sets.
    candidate_set_qualifies = False
    while candidate_set_qualifies == False:

        # algorithmic approach
        # list the indices belonging to each condition
        # then iterate through each run, sample without replacement from each list of indices
        # then we have our groups.
        condition_indices = []
        for c in range(0, 6):
            condition_indices.append(construal_data.index.values[construal_data['Condition'] == (c + 1)])

        candidate_set = [None] * n_runs

        if isinstance(n_trials, int):
            runs_n_trials = [n_trials] * n_runs
        else:
            runs_n_trials = n_trials
        for r in range(0, n_runs):
            n_t = runs_n_trials[r]
            run_vals = []
            # this run has 32 trials.
            extras = (n_t % 6)
            # get the number to select from each condition for this run
            run_condition_count = (
                [int(math.ceil(n_t / 6.0))] * extras + [int(math.floor(n_t / 6.0))] * (6 - extras))
            # shuffle, making sure that we have at least enough.
            while True:
                random.shuffle(run_condition_count)
                if all([c1.__len__() - run_condition_count[ci] >= 0 for ci, c1 in enumerate(condition_indices)]):
                    break
                print "warning: there may not be enough construal items to pick from."

            # now select from condition_indices
            for c in range(0, 6):
                # print(condition_indices[c])
                vals_to_select_for_r_from_c = random.sample(condition_indices[c], run_condition_count[c])
                condition_indices[c] = numpy.setdiff1d(condition_indices[c], vals_to_select_for_r_from_c)
                # run_vals = run_vals + vals_to_select_for_r_from_c
                # instead, should shuffle each of the run vals individually
                random.shuffle(vals_to_select_for_r_from_c)
                # print(vals_to_select_for_r_from_c)
                # and put them into a list of lists
                run_vals.append(vals_to_select_for_r_from_c)

            run_vals_final = []
            # then slice so that the lists are interleaved
            for i in range(0, min(run_condition_count)):
                # this is relying on the fact that the run lengths can only differ by 1
                runval_slice = [v[i] for v in run_vals]
                # then randomize the order of each set of six.
                random.shuffle(runval_slice)
                run_vals_final = run_vals_final + runval_slice
            # finally add the last set, if there's an uneven number of items in each condition.
            if (min(run_condition_count) != max(run_condition_count)):
                last_slice = [rvl[max(run_condition_count) - 1] for j, rvl in enumerate(run_vals) if
                              run_condition_count[j] == max(run_condition_count)]
                random.shuffle(last_slice)
                run_vals_final = run_vals_final + last_slice

            candidate_set[r] = run_vals_final

        # get a random sample of all of the construal trials
        # whole_sample=random.sample(range(0,143),n_trials*n_runs)
        # benefit of the doubt
        candidate_set_qualifies = True
        # iterate through each of the portions in our sample
        # candidate_set=[]
        for portion_i in range(0, n_runs):

            sample_portion = candidate_set[portion_i]  # whole_sample[(portion_i*n_trials):((portion_i+1)*n_trials)]
            # candidate_set.append(sample_portion)
            # check to see that portion's balance score
            sample_means = construal_data.iloc[sample_portion].mean(0)
            # sample_means=pandas.concat([sample_means,getconditionprops(construal_data.iloc[sample_portion])])
            differences = abs(((all_db_means - sample_means) / all_db_means))
            condition_counts = getconditionvals(construal_data.iloc[sample_portion])
            # print differences
            # each portion should differ by less than 2% on the question and answer means
            # and we should have a reasonably similar proportion of true to false answers
            # and at least some false answers!
            # only apply this check to blocks of greater than 8; blocks of less than 8 are practice blocks
            # and we're not concerned about balancing those.
            if runs_n_trials[portion_i] > 10:
                if ((any(differences[['Q_Mean', 'A_Mean']] > 0.02) or any(differences[['Answer']] > 0.1) or
                             sample_means['Answer'] == 1)):
                    # repeat
                    candidate_set_qualifies = False
                    break
                # and also the counts of each individual condition have to be relatively close.
                if max(condition_counts) > (min(condition_counts) + 1):
                    candidate_set_qualifies = False
                    break
    # we got to the end; that means we found a good set!
    print candidate_set
    return candidate_set
    # if it is sufficient, pass the selection out.

def get_construal_data_with_means():
    construal_data = pandas.read_csv('spunt_dataset/data.csv')
    construal_data['Q_Mean'] = construal_data.loc[:, ['Q_Body', 'Q_Spec', 'Q_Conc', 'Q_Imag']].mean(1)
    construal_data['A_Mean'] = construal_data.loc[:, ['A_Body', 'A_Spec', 'A_Conc', 'A_Imag']].mean(1)
    return construal_data

class ItcConstrualConditionDesign:
    RandomCounterbalanced, BlockDesignConcreteFirst,BlockDesignAbstractFirst = range(3)


# class ItcConstrualDesigns:
#     RandomCounterbalanced, SixBlockConditions = range(2)

def get_construal_set_block(n_total_trials,n_runs,condition):
    """
        this should return a set of construal IDs that are divided into exactly 3 blocks.
        They will come in two possible orders. the condition will be set by a variable passed in and accepts either 0 or 1.
        n_runs must be a multiple of 3. If there are more than 3 runs then each set of n_runs/3 runs will be treated as one block for the purposes of this

    :param n_total_trials:
    :param n_runs:
    :return: a set of construal IDs that are divided into exactly 6 blocks.
    """
    #I think we can do this from the
    assert [ItcConstrualConditionDesign.BlockDesignConcreteFirst,ItcConstrualConditionDesign.BlockDesignAbstractFirst].__contains__(condition)
    return get_construal_set(n_total_trials,n_runs,n_repeats=1,construal_design=condition)

def get_balanced_construal_set_2(n_total_trials, n_runs, n_repeats=1,require_balance_from_trial=None):
    #for construal, require_balance_from_trial has to be spaced at least n_repeats*6 apart.
    spaces_apart=[b-a for a,b in zip(require_balance_from_trial[0:-1],require_balance_from_trial[1:])]
    construal_balance_trials=[require_balance_from_trial[0]]
    a=0
    for i, b in enumerate(require_balance_from_trial[1:]):
        s=spaces_apart[i]
        a=a+s
        if a>=n_repeats*6:
            construal_balance_trials =construal_balance_trials+[require_balance_from_trial[i+1]]
            a=0

    return get_construal_set(n_total_trials, n_runs, n_repeats,
                             construal_design=ItcConstrualConditionDesign.RandomCounterbalanced,
                             require_balance_from_trial=construal_balance_trials)


def get_construal_set(n_total_trials, n_runs, n_repeats=1, construal_design=ItcConstrualConditionDesign.RandomCounterbalanced,
                      require_balance_from_trial=None):
    """

    :param n_total_trials: int describing number of trials in each run, or n_runs-length list describing number of trials in each run.
    :param n_runs: number of runs.
    :param require_balance_throughout_task: if set to true, this will ensure that the set is relatively balanced regardless of how long it is being run for.
    :return:
    """
    # Need to improve by:
    # allowing to duplicate within-number sets (e.g., follow every condition 1 with another condition 1)

    # set n_trials to be divied by the number of repeats of each condition type
    try:
        if any([x % n_repeats > 0 for x in n_total_trials]):
            raise Exception("n_total_trials must be a multiple of n_repeats")
        n_trials = [x / n_repeats for x in n_total_trials]
    except TypeError, te:
        if n_total_trials % n_repeats > 0:
            raise Exception("n_total_trials must be a multiple of n_repeats")
        n_trials = n_total_trials / n_repeats
    # hello.

    # for the SixBlockConditions design, n_runs must be a multiple of 3
    # and there must block condition specified
    if [ItcConstrualConditionDesign.BlockDesignConcreteFirst,ItcConstrualConditionDesign.BlockDesignAbstractFirst].__contains__(construal_design):
        assert (n_runs % 6 == 0)
        #assert SixBlockConditions_condition is not None

    #only allow a SixBlockConditionsCondition for SixBlockConditions; otherwise it makes no sense.
    #if construal_design ==ItcConstrualConditionDesign.RandomCounterbalanced:
    #    assert SixBlockConditions_condition is None

    # allowing to add a mirror set after the original (
    # construal_seeker = pandas.read_csv('spunt_dataset/seeker.csv')
    construal_data = get_construal_data_with_means()
    all_db_means = construal_data.mean(0)


    getconditionprops = lambda x: x.groupby('Condition').count()['A_Mean'] / x.count()['A_Mean']
    getconditionvals = lambda x: x.groupby('Condition').count()['A_Mean']

    # all_db_means=pandas.concat([all_db_means,getconditionprops(construal_data)])
    # get the target means for each run

    condition_indices_range=[None]*n_runs
    run_target_means = [None]*n_runs
    #determine the range of conditions for each run.
    #conditions are numbered 0 through 5 here.
    for r in range(0,n_runs):
        if construal_design == ItcConstrualConditionDesign.RandomCounterbalanced:
            condition_indices_range[r] = range(0, 6) # select from all conditions for every run.
        elif [ItcConstrualConditionDesign.BlockDesignConcreteFirst,ItcConstrualConditionDesign.BlockDesignAbstractFirst].__contains__(construal_design):
            if construal_design == ItcConstrualConditionDesign.BlockDesignAbstractFirst:
                # go from abstract to concrete
                condition_indices_range[r] = [5 - (r / (n_runs / 6))] #select from a set of conditions for every run.
            elif construal_design == ItcConstrualConditionDesign.BlockDesignConcreteFirst:
                # go from concrete to abstract
                condition_indices_range[r] = [0+ (r / (n_runs / 6))]  # select from a set of conditions for every run.
        #get the means we want to target for each run.
        run_target_means[r] = construal_data[construal_data.Condition.isin([i+1 for i in condition_indices_range[r]])].mean(0)




    # loop through possible candidate sets.
    candidate_set_qualifies = False
    while candidate_set_qualifies == False:

        # algorithmic approach

        # list the indices belonging to each condition
        condition_indices = []
        for c in range(0, 6):
            condition_indices.append(construal_data.index.values[construal_data['Condition'] == (c + 1)])

        # then iterate through each run, sample without replacement from each list of indices
        # then we have our groups.
        candidate_set = [None] * n_runs

        #make sure runs_n_trials is a list of integers, one for each run.
        if isinstance(n_trials, int):
            runs_n_trials = [n_trials] * n_runs
        else:
            runs_n_trials = n_trials

        for r in range(0, n_runs):
            n_t = runs_n_trials[r]
            run_vals = []
            # this run has 32 trials.
            extras = (n_t % 6)
            # get the number to select from each condition for this run
            run_condition_count = (
                [int(math.ceil(n_t / 6.0))] * extras + [int(math.floor(n_t / 6.0))] * (6 - extras))
            # shuffle, making sure that we have at least enough.
            while True:
                random.shuffle(run_condition_count)

                #make sure there's enough items to choose from for the size of trial that we want.
                if all([c1.__len__() - run_condition_count[ci] >= 0 for ci, c1 in enumerate(condition_indices)]):
                    break
                print "warning: there may not be enough construal items to pick from."

            # now select from condition_indices for this run.
            for c in condition_indices_range[r]:
                #select a few indicess from each condition.
                vals_to_select_for_r_from_c = random.sample(condition_indices[c], run_condition_count[c]*n_repeats)
                #update the condition index list to remove the values we "used".
                condition_indices[c] = numpy.setdiff1d(condition_indices[c], vals_to_select_for_r_from_c)

                # instead, should shuffle each of the run vals individually
                random.shuffle(vals_to_select_for_r_from_c)
                # print(vals_to_select_for_r_from_c)
                # and put them into a list of lists
                run_vals.append(vals_to_select_for_r_from_c)

            run_vals_final = []
            # then slice so that the lists are interleaved.
            # This is all pretty redundant for block-designs, but it's harmless.
            for i in range(0, min(run_condition_count)):
                # this is relying on the fact that the run lengths can only differ by 1
                #we're potentially going to take more than one value each time
                runval_slice = [v[(i*n_repeats):(i*n_repeats+2)] for v in run_vals]
                # then randomize the order of each set of six.
                random.shuffle(runval_slice)
                #OK, so if n_repeats>1 then runval_slice will be a list of lists; time to flatten.
                if n_repeats>1:#flatten the list
                    runval_slice = [item for sublist in runval_slice for item in sublist]
                run_vals_final = run_vals_final + runval_slice
            # finally add the last set, if there's an uneven number of items in each condition.
            if (min(run_condition_count) != max(run_condition_count)):
                #ahh, for each group rvl where we want an extra run out of it, pick the nth value (because weouldn't have picked it before now)
                rangemin=(max(run_condition_count) - 1)*n_repeats
                rangemax=rangemin+2
                last_slice = [rvl[rangemin:rangemax] for j, rvl in enumerate(run_vals) if
                              run_condition_count[j] == max(run_condition_count)]
                random.shuffle(last_slice)
                if n_repeats>1:#flatten the list
                    last_slice = [item for sublist in last_slice for item in sublist]
                run_vals_final = run_vals_final + last_slice

            candidate_set[r] = run_vals_final

        #now TEST TO SEE IF THIS SET WORKS.
        # get a random sample of all of the construal trials
        # benefit of the doubt
        candidate_set_qualifies = True
        # iterate through each of the portions in our sample
        # candidate_set=[]
        for portion_i in range(0, n_runs):
            #do we want to just check the whole set, or are we interested in making sure that the set is balanced throughout?
            if require_balance_from_trial is None:
                check_point = [len(candidate_set[portion_i])]
            elif hasattr(require_balance_from_trial, '__iter__'):
                check_point = require_balance_from_trial
            else:
                #we require balance from a particular trial onwards so let's make sure that's set up!
                check_point = [i*6*n_repeats for i in range(require_balance_from_trial/(6*n_repeats), len(candidate_set[portion_i])/(6*n_repeats))]

            for check_point_i in check_point:


                sample_portion = candidate_set[portion_i][0:check_point_i]  # whole_sample[(portion_i*n_trials):((portion_i+1)*n_trials)]
                # check to see that portion's balance score
                sample_means = construal_data.iloc[sample_portion].mean(0)
                #these are potentially different for each run to allow for the mTurk version
                # in which different versoins
                differences = abs(((run_target_means[portion_i] - sample_means) / run_target_means[portion_i]))
                condition_counts = getconditionvals(construal_data.iloc[sample_portion])
                # print differences
                # each portion should differ by less than 2% on the question and answer means
                # and we should have a reasonably similar proportion of true to false answers
                # and at least some false answers!
                # only apply this check to blocks of greater than 8; blocks of less than 8 are practice blocks
                # and we're not concerned about balancing those.
                if runs_n_trials[portion_i] > 10:
                    if ((any(differences[['Q_Mean', 'A_Mean']] > 0.02) or any(differences[['Answer']] > 0.1) or
                                 sample_means['Answer'] == 1)):
                        # repeat
                        candidate_set_qualifies = False
                        break
                    # and also the counts of each individual condition have to be relatively close.
                    if max(condition_counts) > (min(condition_counts) + 1):
                        candidate_set_qualifies = False
                        break

            if candidate_set_qualifies==False:
                #print "broke on " + str(check_point_i)
                break
    # we got to the end; that means we found a good set!
    print candidate_set
    return candidate_set
    # if it is sufficient, pass the selection out.
