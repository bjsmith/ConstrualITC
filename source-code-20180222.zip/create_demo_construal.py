from ItcConstrualTaskManager import *
create_itc_construal_script_set(range(1,16),1,2,20,'lab_demo')